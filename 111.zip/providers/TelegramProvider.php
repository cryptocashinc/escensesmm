<?php
namespace Escense\SMM\Providers;
function http_post_json(string $url, array $payload){
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true, CURLOPT_HTTPHEADER=>['Content-Type: application/json'], CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE), CURLOPT_TIMEOUT=>60]);
  $res=curl_exec($ch); $err=curl_error($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  return [$code,$res,$err];
}
function http_post_multipart(string $url, array $fields){
  foreach($fields as $k=>$v){ if(is_string($v) && is_file($v)) $fields[$k]=new \CURLFile($v); }
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>$fields, CURLOPT_TIMEOUT=>120]);
  $res=curl_exec($ch); $err=curl_error($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  return [$code,$res,$err];
}
function dec_token(string $b64){
  $raw=base64_decode($b64,true); if($raw===false||strlen($raw)<28) return '';
  $iv=substr($raw,0,12); $tag=substr($raw,12,16); $cipher=substr($raw,28);
  $key=hash('sha256', APP_KEY, true);
  $plain=openssl_decrypt($cipher,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);
  return $plain===false?'':$plain;
}
class TelegramProvider implements ProviderInterface{
  public static function publish(array $row): array {
    $token=dec_token($row['access_token']); $chat=$row['external_id']; $body=$row['body'] ?? ''; $media=json_decode($row['media_json'] ?? '[]',true) ?: [];
    if($media && ($media[0]['type'] ?? '')==='image'){
      [$code,$res,$err]=http_post_multipart("https://api.telegram.org/bot{$token}/sendPhoto",['chat_id'=>$chat,'photo'=>$media[0]['url'],'caption'=>$body]);
    } else if($media && ($media[0]['type'] ?? '')==='video'){
      [$code,$res,$err]=http_post_multipart("https://api.telegram.org/bot{$token}/sendVideo",['chat_id'=>$chat,'video'=>$media[0]['url'],'caption'=>$body]);
    } else {
      [$code,$res,$err]=http_post_json("https://api.telegram.org/bot{$token}/sendMessage",['chat_id'=>$chat,'text'=>$body]);
    }
    if($code>=200 && $code<300){ $data=json_decode($res,true); $mid=$data['result']['message_id'] ?? ''; return [true,(string)$mid,'']; }
    return [false,'',"HTTP $code: $err $res"];
  }
}
