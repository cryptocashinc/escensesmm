<?php
namespace Escense\SMM\Providers;
require_once __DIR__ . '/../inc/functions.php';
require_once __DIR__ . '/ProviderInterface.php';
require_once __DIR__ . '/TelegramProvider.php';
require_once __DIR__ . '/VKProvider.php';
class BaseProvider {
  public static function publishRow(array $row): array {
    $key=$row['provider_key'] ?? '';
    switch($key){
      case 'telegram': return TelegramProvider::publish($row);
      case 'vk': return VKProvider::publish($row);
      default: return [false,'','Provider not implemented'];
    }
  }
}
