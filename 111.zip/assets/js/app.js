function toggleSidebar(){ document.getElementById('sidebar').classList.toggle('open'); }

// Tooltips "?" — toggle popovers; close on outside/escape
document.addEventListener('click', (e)=>{
  if (!e.target.closest('.help')) {
    document.querySelectorAll('.help .q[aria-expanded="true"]').forEach(btn=>btn.setAttribute('aria-expanded','false'));
  }
  const q = e.target.closest('.help .q');
  if (q){
    const expanded = q.getAttribute('aria-expanded') === 'true';
    document.querySelectorAll('.help .q[aria-expanded="true"]').forEach(btn=>btn.setAttribute('aria-expanded','false'));
    q.setAttribute('aria-expanded', expanded ? 'false' : 'true');
  }
});
document.addEventListener('keydown',(e)=>{
  if (e.key==='Escape'){
    document.querySelectorAll('.help .q[aria-expanded="true"]').forEach(btn=>btn.setAttribute('aria-expanded','false'));
  }
});

// Provider help switcher on Accounts page
function providerHelpChange(selId, helpId){
  const sel = document.getElementById(selId);
  const box = document.getElementById(helpId);
  if (!sel || !box) return;
  const value = sel.value;
  const map = {
    'telegram': `
      <strong>Telegram</strong> — нужен <em>бот-токен</em> от @BotFather и <em>chat_id</em> канала/чата.
      <ul><li>Добавьте бота админом в канал.</li><li>chat_id: @alias (публ.) или числовой ID (приват.).</li></ul>`,
    'vk': `
      <strong>VK</strong> — токен сообщества и <em>owner_id</em> группы.
      <ul><li>owner_id для сообщества: <code>-{id_группы}</code> (минус обязателен).</li><li>Токен: Настройки сообщества → Работа с API.</li></ul>`,
    'facebook': `
      <strong>Facebook Page</strong> — Page Access Token и <em>page_id</em>.
      <ul><li>Через Meta Graph API; желательно long‑lived токен.</li></ul>`,
    'instagram': `
      <strong>Instagram</strong> — <em>ig_user_id</em> + токен из Graph API (страница FB должна быть связана).</li>`,
    'linkedin': `
      <strong>LinkedIn</strong> — токен + <em>organization URN</em> (или person URN).</li>`,
    'tiktok': `<strong>TikTok</strong> — OAuth в разработке.`,
    'youtube': `<strong>YouTube</strong> — OAuth клиента и channelId.`,
    'threads': `<strong>Threads</strong> — пока заглушка.`
  };
  box.innerHTML = map[value] || 'Выберите провайдера — появятся инструкции.';
}
