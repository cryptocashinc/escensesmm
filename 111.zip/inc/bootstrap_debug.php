<?php
error_reporting(E_ALL); ini_set('display_errors','1'); ini_set('log_errors','1');
set_error_handler(function($severity, $message, $file, $line){
  if (!(error_reporting() & $severity)) return false;
  if (!headers_sent()) header('Content-Type: text/html; charset=utf-8');
  echo "<pre style='margin:8px 0;padding:10px;border:1px solid #400;background:#200;color:#fdd;font:13px/1.4 monospace'>PHP ERROR [$severity]\n".htmlspecialchars($message)."\n".htmlspecialchars($file).":$line</pre>";
  return false;
});
register_shutdown_function(function(){
  $e = error_get_last(); if (!$e) return;
  $fatal=[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR];
  if(!in_array($e['type'],$fatal,true)) return;
  if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8', true, 500);
  echo "⛑️ FATAL ERROR\nType: {$e['type']}\nMessage: {$e['message']}\nFile: {$e['file']}\nLine: {$e['line']}\n";
});
