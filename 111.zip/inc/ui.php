<?php
require_once __DIR__ . '/bootstrap_debug.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';

function ui_header(string $title='SMM', string $active='calendar'){ ?>
<!DOCTYPE html><html lang="ru"><head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?=h($title)?></title>
  <link rel="stylesheet" href="assets/css/app.css?v=1.6">
</head><body>
  <header class="header">
    <img src="../img/logo.svg" alt="escense">
    <div class="actions">
      <button class="btn menu-btn" onclick="toggleSidebar()">меню</button>
      <a class="btn" href="../admin_projects.php">центр</a>
      <a class="btn" href="../logout.php">выйти</a>
    </div>
  </header>
  <div class="layout">
    <aside class="sidebar" id="sidebar">
      <nav class="nav">
        <div class="nav-group">
          <div class="nav-title">публикации</div>
          <a class="{ $active==='calendar'?'active':'' }" href="calendar.php"><svg viewBox="0 0 24 24" fill="none"><path d="M7 3v3M17 3v3M3 9h18M5 6h14a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z" stroke="currentColor" stroke-width="1.6"/></svg><span>календарь</span></a>
          <a class="{ $active==='posts'?'active':'' }" href="posts.php"><svg viewBox="0 0 24 24" fill="none"><path d="M5 7h14M5 12h14M5 17h9" stroke="currentColor" stroke-width="1.6"/></svg><span>посты</span></a>
          <a class="{ $active==='new'?'active':'' }" href="post_edit.php"><svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="1.6"/></svg><span>новый пост</span></a>
          <a class="{ $active==='queue'?'active':'' }" href="targets.php"><svg viewBox="0 0 24 24" fill="none"><path d="M7 8h10M7 12h10M7 16h6" stroke="currentColor" stroke-width="1.6"/></svg><span>очередь</span></a>
        </div>
        <div class="nav-group">
          <div class="nav-title">управление</div>
          <a class="{ $active==='accounts'?'active':'' }" href="accounts.php"><svg viewBox="0 0 24 24" fill="none"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm8 9a8 8 0 0 0-16 0" stroke="currentColor" stroke-width="1.6"/></svg><span>аккаунты</span></a>
          <a class="{ $active==='reports'?'active':'' }" href="reports.php"><svg viewBox="0 0 24 24" fill="none"><path d="M5 12v7M10 9v10M15 14v5M20 4v15" stroke="currentColor" stroke-width="1.6"/></svg><span>отчёты</span></a>
          <a class="{ $active==='logs'?'active':'' }" href="logs.php"><svg viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" stroke-width="1.6"/></svg><span>логи</span></a>
        </div>
      </nav>
    </aside>
    <main class="main">
<?php }
function ui_footer(){ ?>
    </main>
  </div>
  <div class="actionbar"><a class="btn" href="post_edit.php">+ новый пост</a></div>
  <script src="assets/js/app.js?v=1.6"></script>
</body></html>
<?php }
