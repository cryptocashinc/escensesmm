<?php
// /public_html/escense/smm/inc/provider.php
if (session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/functions.php'; // http_* + crypto

function tg_norm_chat(string $ext): string {
  $ext = trim($ext);
  if (preg_match('~^https?://t\.me/([A-Za-z0-9_]+)$~i',$ext,$m)) $ext='@'.$m[1];
  if ($ext !== '' && $ext[0] !== '@' && !preg_match('~^-?\d+$~',$ext)) $ext='@'.$ext;
  return $ext;
}

function abs_url(string $u): string {
  if ($u==='' ) return $u;
  if (preg_match('~^https?://~i',$u)) return $u;
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http';
  $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
  if ($u[0] !== '/') $u = '/'.$u;
  return $scheme.'://'.$host.$u;
}

/**
 * Универсальная отправка поста в провайдера.
 * $tokenPlain — ПЛЕЙН (у воркера мы заранее делаем dec_token).
 * $payload: ['text','link','first_comment','media'=>[['url'|'path','type']]]
 */
function provider_send(string $provider, string $tokenPlain, string $externalId, array $payload): array {
  switch (strtolower($provider)) {
    case 'telegram': {
      $chat = tg_norm_chat($externalId);
      $text = trim((string)($payload['text'] ?? ''));
      $link = trim((string)($payload['link'] ?? ''));
      $fc   = trim((string)($payload['first_comment'] ?? ''));

      // media (url/path -> abs_url)
      $mediaArr = [];
      foreach (($payload['media'] ?? []) as $m) {
        $src = $m['url'] ?? $m['path'] ?? '';
        if (!$src) continue;
        $src = abs_url($src);
        $typ = $m['type'] ?? '';
        if ($typ==='') {
          if (preg_match('~\.(mp4)$~i',$src)) $typ='video';
          elseif (preg_match('~\.(jpe?g|png|gif|webp)$~i',$src)) $typ='image';
        }
        $mediaArr[] = ['type'=>$typ ?: 'image', 'url'=>$src];
      }

      $parts=[]; if($text!=='') $parts[]=$text; if($link!=='') $parts[]=$link;
      $captionText = implode("\n\n",$parts);
      $caption     = mb_substr($captionText, 0, 1024);

      $api = function(string $method, array $fields) use ($tokenPlain): array {
        $url = "https://api.telegram.org/bot{$tokenPlain}/{$method}";
        return http_post_form($url, $fields);
      };

      if (count($mediaArr)===0) {
        [$code,$body,$e] = $api('sendMessage', [
          'chat_id'=>$chat, 'text'=>($captionText!==''?$captionText:' '), 'disable_web_page_preview'=>false
        ]);
        $jr = $body? json_decode($body,true): null;
        if ($code===200 && !empty($jr['ok'])) {
          if ($fc!=='') $api('sendMessage',['chat_id'=>$chat,'text'=>$fc]);
          return [true,''];
        }
        return [false, "tg sendMessage code={$code} body=".substr((string)$body,0,200)." e={$e}"];
      }

      if (count($mediaArr)===1) {
        $m = $mediaArr[0];
        if ($m['type']==='video') {
          [$code,$body,$e] = $api('sendVideo', ['chat_id'=>$chat,'video'=>$m['url'],'caption'=>$caption]);
        } else {
          [$code,$body,$e] = $api('sendPhoto', ['chat_id'=>$chat,'photo'=>$m['url'],'caption'=>$caption]);
        }
        $jr = $body? json_decode($body,true): null;
        if ($code===200 && !empty($jr['ok'])) {
          if ($fc!=='') $api('sendMessage',['chat_id'=>$chat,'text'=>$fc]);
          return [true,''];
        }
        return [false, "tg media code={$code} body=".substr((string)$body,0,200)." e={$e}"];
      }

      // альбом 2..10
      $album=[]; $i=0;
      foreach ($mediaArr as $m) {
        if ($i>=10) break;
        $typ = ($m['type']==='video')?'video':'photo';
        $item = ['type'=>$typ,'media'=>$m['url']];
        if ($i===0 && $caption!=='') $item['caption']=$caption;
        $album[]=$item; $i++;
      }
      [$code,$body,$e] = $api('sendMediaGroup', ['chat_id'=>$chat,'media'=>json_encode($album, JSON_UNESCAPED_UNICODE)]);
      $jr = $body? json_decode($body,true): null;
      if ($code===200 && !empty($jr['ok'])) {
        if ($fc!=='') $api('sendMessage',['chat_id'=>$chat,'text'=>$fc]);
        return [true,''];
      }
      return [false, "tg album code={$code} body=".substr((string)$body,0,200)." e={$e}"];
    }

    case 'vk': {
      // как твой тест: только текст (медиа VK — отдельная история)
      $owner = trim($externalId);
      $parts=[]; if(!empty($payload['text'])) $parts[]=$payload['text'];
      if (!empty($payload['link'])) $parts[]=$payload['link'];
      $message = $parts ? implode("\n\n",$parts) : ' ';
      [$c,$r,$e] = http_post_form("https://api.vk.com/method/wall.post", [
        'owner_id'=>$owner, 'message'=>$message, 'v'=>'5.199', 'access_token'=>$tokenPlain
      ]);
      $j = $r ? json_decode($r,true) : null;
      if ($c===200 && isset($j['response']['post_id'])) return [true,''];
      return [false, "vk wall.post fail code={$c} body=".substr((string)$r,0,200)." e={$e}"];
    }

    default:
      return [false, "provider {$provider} not implemented"];
  }
}
