<?php
require_once __DIR__ . '/db.php';
// Require admin like your admin panel
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
  header('Location: ../index.php'); exit;
}
function scope_posts_clause(string $alias='p'): array {
  // admin module — no extra filtering; if you want client scoping later, add here
  return ['', []];
}
