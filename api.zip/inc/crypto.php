<?php
// Если флаг не задан — по умолчанию шифрование выключено (plaintext)
if (!defined('SMM_ENCRYPT_TOKENS')) define('SMM_ENCRYPT_TOKENS', false);

/**
 * Сохранение токена:
 *  - при SMM_ENCRYPT_TOKENS=false — возвращаем как есть (plaintext);
 *  - при true — AES-256-GCM + base64.
 */
function enc_token(string $plain): string {
  $plain = trim((string)$plain);
  if ($plain === '') return '';

  if (!SMM_ENCRYPT_TOKENS) {
    return $plain; // без шифрования
  }

  if (!defined('APP_KEY')) {
    throw new \RuntimeException('APP_KEY не задан (нужен для шифрования)');
  }

  $key = hash('sha256', APP_KEY, true);
  $iv  = random_bytes(12);
  $tag = '';
  $cipher = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
  return base64_encode($iv . $tag . $cipher);
}

/**
 * Чтение токена:
 *  - при SMM_ENCRYPT_TOKENS=false — считаем, что в БД plaintext,
 *    НО если попадётся старый base64-зашифрованный — попробуем расшифровать (бэкомпат);
 *  - при true — ожидаем base64 и расшифровываем.
 */
function dec_token(string $val): string {
  $val = trim((string)$val);
  if ($val === '') return '';

  if (!SMM_ENCRYPT_TOKENS) {
    // Бэкомпат: вдруг в БД старые base64-записи — аккуратно пробуем расшифровать
    $raw = base64_decode($val, true);
    if ($raw !== false && strlen($raw) >= 28 && defined('APP_KEY')) {
      $iv   = substr($raw, 0, 12);
      $tag  = substr($raw, 12, 16);
      $data = substr($raw, 28);
      $key  = hash('sha256', APP_KEY, true);
      $plain = openssl_decrypt($data, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
      if ($plain !== false && $plain !== '') {
        return $plain; // успешно распаковали старое
      }
    }
    return $val; // обычный plaintext
  }

  // Шифрование включено — ожидаем base64 и расшифровываем
  if (!defined('APP_KEY')) {
    throw new \RuntimeException('APP_KEY не задан (нужен для расшифровки)');
  }
  $raw = base64_decode($val, true);
  if ($raw === false || strlen($raw) < 28) return '';
  $iv   = substr($raw, 0, 12);
  $tag  = substr($raw, 12, 16);
  $data = substr($raw, 28);
  $key  = hash('sha256', APP_KEY, true);
  $plain = openssl_decrypt($data, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
  return $plain === false ? '' : $plain;
}