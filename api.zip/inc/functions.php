<?php
// ===== include guard & marker =====
if (defined('ESC_SMM_FUNCS_LOADED')) return;
define('ESC_SMM_FUNCS_LOADED', true);

if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Подключаем БД и крипту
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/crypto.php';

// ===== Утилиты =====
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function json_response($data, int $code = 200){
  if (!headers_sent()) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
  }
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}

function user_id(): int { return (int)($_SESSION['user_id'] ?? 0); }

// ===== HTTP helpers (cURL + IPv4; fallback streams) =====
function http_get_raw(string $url): array {
  if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_CONNECTTIMEOUT => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_SSL_VERIFYPEER => true,
      CURLOPT_SSL_VERIFYHOST => 2,
      CURLOPT_USERAGENT => 'Escense-SMM/1.0',
      CURLOPT_IPRESOLVE => defined('CURL_IPRESOLVE_V4') ? CURL_IPRESOLVE_V4 : 1,
    ]);
    $res  = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$code, $res === false ? '' : $res, $err];
  }
  $ctx = stream_context_create([
    'http' => ['method'=>'GET','timeout'=>30,'header'=>"User-Agent: Escense-SMM/1.0\r\n"],
    'ssl'  => ['verify_peer'=>true,'verify_peer_name'=>true],
  ]);
  $res = @file_get_contents($url, false, $ctx);
  $err = $res === false ? (error_get_last()['message'] ?? 'stream error') : '';
  $code = 0;
  if (isset($http_response_header) && is_array($http_response_header)) {
    foreach ($http_response_header as $hline) {
      if (preg_match('#^HTTP/\d\.\d\s+(\d{3})#', $hline, $m)) { $code = (int)$m[1]; break; }
    }
  }
  return [$code, $res === false ? '' : $res, $err];
}

function http_post_form(string $url, array $fields): array {
  if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_POST => true,
      CURLOPT_POSTFIELDS => http_build_query($fields),
      CURLOPT_CONNECTTIMEOUT => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_SSL_VERIFYPEER => true,
      CURLOPT_SSL_VERIFYHOST => 2,
      CURLOPT_USERAGENT => 'Escense-SMM/1.0',
      CURLOPT_IPRESOLVE => defined('CURL_IPRESOLVE_V4') ? CURL_IPRESOLVE_V4 : 1,
    ]);
    $res  = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$code, $res === false ? '' : $res, $err];
  }
  $ctx = stream_context_create([
    'http' => [
      'method'=>'POST','timeout'=>30,
      'header'=>"Content-Type: application/x-www-form-urlencoded\r\nUser-Agent: Escense-SMM/1.0\r\n",
      'content'=> http_build_query($fields),
    ],
    'ssl'  => ['verify_peer'=>true,'verify_peer_name'=>true],
  ]);
  $res = @file_get_contents($url, false, $ctx);
  $err = $res === false ? (error_get_last()['message'] ?? 'stream error') : '';
  $code = 0;
  if (isset($http_response_header) && is_array($http_response_header)) {
    foreach ($http_response_header as $hline) {
      if (preg_match('#^HTTP/\d\.\d\s+(\d{3})#', $hline, $m)) { $code = (int)$m[1]; break; }
    }
  }
  return [$code, $res === false ? '' : $res, $err];
}

function http_post_json(string $url, array $payload): array {
  $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
  if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_POST => true,
      CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
      CURLOPT_POSTFIELDS => $json,
      CURLOPT_CONNECTTIMEOUT => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_SSL_VERIFYPEER => true,
      CURLOPT_SSL_VERIFYHOST => 2,
      CURLOPT_USERAGENT => 'Escense-SMM/1.0',
      CURLOPT_IPRESOLVE => defined('CURL_IPRESOLVE_V4') ? CURL_IPRESOLVE_V4 : 1,
    ]);
    $res  = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$code, $res === false ? '' : $res, $err];
  }
  $ctx = stream_context_create([
    'http' => [
      'method'=>'POST','timeout'=>30,
      'header'=>"Content-Type: application/json\r\nUser-Agent: Escense-SMM/1.0\r\n",
      'content'=> $json,
    ],
    'ssl'  => ['verify_peer'=>true,'verify_peer_name'=>true],
  ]);
  $res = @file_get_contents($url, false, $ctx);
  $err = $res === false ? (error_get_last()['message'] ?? 'stream error') : '';
  $code = 0;
  if (isset($http_response_header) && is_array($http_response_header)) {
    foreach ($http_response_header as $hline) {
      if (preg_match('#^HTTP/\d\.\d\s+(\d{3})#', $hline, $m)) { $code = (int)$m[1]; break; }
    }
  }
  return [$code, $res === false ? '' : $res, $err];
}