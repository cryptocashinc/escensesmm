<?php
namespace Escense\SMM\Providers;
function http_post_json_vk(string $url, array $payload){
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>http_build_query($payload), CURLOPT_TIMEOUT=>60]);
  $res=curl_exec($ch); $err=curl_error($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  return [$code,$res,$err];
}
function dec_token_vk(string $b64){
  $raw=base64_decode($b64,true); if($raw===false||strlen($raw)<28) return '';
  $iv=substr($raw,0,12); $tag=substr($raw,12,16); $cipher=substr($raw,28);
  $key=hash('sha256', APP_KEY, true);
  $plain=openssl_decrypt($cipher,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);
  return $plain===false?'':$plain;
}
class VKProvider implements ProviderInterface{
  public static function publish(array $row): array {
    $token=dec_token_vk($row['access_token']); $owner=$row['external_id']; $message=$row['body'] ?? '';
    [$code,$res,$err]=http_post_json_vk("https://api.vk.com/method/wall.post",[
      'owner_id'=>$owner,'message'=>$message,'v'=>'5.199','access_token'=>$token
    ]);
    $data=json_decode($res,true);
    if($code==200 && isset($data['response']['post_id'])) return [true,(string)$data['response']['post_id'],''];
    $errMsg=$data['error']['error_msg'] ?? ("HTTP $code: $err");
    return [false,'',$errMsg];
  }
}
