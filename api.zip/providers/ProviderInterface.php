<?php namespace Escense\SMM\Providers;
interface ProviderInterface{ public static function publish(array $row): array; }
